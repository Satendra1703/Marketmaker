export const TOKEN_MINT = "4Cnk9EPnW5ixfLZatCPJjDB1PUtcRpVVgTQukm9epump"
export const TOKEN_SYMBOL = 'DADDY'
export const BASE_AMOUNT = 500
