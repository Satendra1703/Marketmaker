export const TOKEN_MINT = "4Cnk9EPnW5ixfLZatCPJjDB1PUtcRpVVgTQukm9epump"
export const TOKEN_SYMBOL = 'DADDY'
export const BASE_AMOUNT = 50
export const TIME_INTERVAL = 30000 // min
export const SMALL_AMOUNT = 10